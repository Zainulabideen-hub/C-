#include<iostream>
using namespace std;
int main(){
int i = 0; 
while (i <= 20)
{ //Line 3
 cout << i << " "; 
 i = i + 5;
}
    
    return 0;
}