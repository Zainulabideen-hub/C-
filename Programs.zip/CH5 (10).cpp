#include<iostream>
using namespace std;

int main()
{ int i;
   for (i = 1; i <= 5; i++)
{
 cout << "Hello!" << endl;
 cout << "*" << endl;
}
    return 0;
}