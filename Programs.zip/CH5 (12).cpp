#include<iostream>
using namespace std;

int main()
{
    int i;
   for (i = 0; i < 5; i++); //Line 1
 cout << "*" << endl; //Line 2
    return 0;
}