#include<iostream>
using namespace std;

int main()
{
    int i;
  for (i = 10; i >= 1; i--)
 cout << " " << i;
cout << endl;
    return 0;
}