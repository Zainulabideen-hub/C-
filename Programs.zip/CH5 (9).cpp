#include<iostream>
using namespace std;

int main()
{
   for (i = 0; i < 10; i++)
 cout << i << " ";
cout << endl;
    return 0;
}