#include <iostream>
#include <string>

using namespace std;

int main()
{
    // Assume 'month' is declared and has a value
    int month = 2; // Example value

    if (month == 1)
        cout << "January" << endl;
    if (month == 2)
        cout << "February" << endl;
    if (month == 3)
        cout << "March" << endl;
    if (month == 4)
        cout << "April" << endl;
    if (month == 5)
        cout << "May" << endl;
    if (month == 6)
        cout << "June" << endl;

    // Output for month = 2: "February"

    return 0;
}
