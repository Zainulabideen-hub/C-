#include <iostream>

using namespace std;

int main() {
    int i = 11;

    while (i <= 10) {
        cout << i << " ";
        i = i + 5;
    }

    cout << endl;

    return 0;
}
