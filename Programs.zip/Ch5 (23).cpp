#include <iostream>

using namespace std;

int main() {
    int i = 0;

    do {
        cout << i << " ";
        i = i + 5;
    }
    while (i <= 20);

    return 0;
}
