#include<iostream>
using namespace std;

int main()
{
string name;
cout << "Please Enter your name: ";
cin >> name;
if (name == "ali"){
cout<< "Welcome "<< name;
}
if (name != "ali"){
cout<< "Try again!";
}
}
