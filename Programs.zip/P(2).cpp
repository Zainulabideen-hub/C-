#include<iostream>
using namespace std;

int main()
{
    string name;
    cout << "Enter country name" << endl;
    cin >> name;
    if(name!="germany"||name!="australia"){
    cout << "You should come to visit these sometime!" << endl;}
    return 0;
}