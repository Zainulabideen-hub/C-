#include<iostream>
using namespace std;

int main()
{
    int sum,n;
    sum=0;
    cout << "Enter first number" << endl;
    cin >> n;
    sum=sum+n;
    cout << "Enter second number" << endl;
    cin >> n;
    sum=sum+n;
    cout << "Enter third number" << endl;
    cin >> n;
    sum=sum+n;
    cout << "Enter forth number" << endl;
    cin >> n;
    sum=sum+n;
    cout << "Enter fifth number" << endl;
    cin >> n;
    sum=sum+n;
    cout << "Sum:"<<sum << endl;
    return 0;
}