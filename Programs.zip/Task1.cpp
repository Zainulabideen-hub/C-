#include<iostream>
using namespace std;

int main()
{
    string name;
    int rollno;
    float agg;
    char section;
    cout << "Enter your name" << endl;
    cin >> name;
    cout << "Enter roll no" << endl;
    cin >> rollno;
    cout << "Enter aggregate" << endl;
    cin >> agg;
    cout << "Enter section" << endl;
    cin >> section;
    cout << "Name:"<<name << endl ;
    cout << "Rollno:"<<rollno << endl;
    cout << "Aggregate:" <<agg<< endl;
    cout << "Section:"<<section << endl;
    return 0;
}