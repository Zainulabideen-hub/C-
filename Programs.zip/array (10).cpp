#include <iostream>
using namespace std;
int main() {

    char pk[]="Pakistan";

    cout<<pk;
    return 0;

}