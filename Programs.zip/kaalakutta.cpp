#include<iostream>
using namespace std;

int main()
{
    float a,b;
    char ch;
    cout << "Enter the numbers" << endl;
    cin >> a >> b;
    cout << "Enter A for addition,S for subtraction,D for division and M for multiplication" << endl;
    cin >> ch;
    if (ch=='A')
    cout << "Result " << a+b << endl;
    else if (ch=='S')
    cout << "Result " << a-b << endl;
    else if (ch=='D')
    cout << "Result "<< a/b << endl;
    else if (ch == 'M')
    cout << "Result"<<a*b << endl;
    else
    cout << "Enter a valid character" << endl;
    return 0;
}