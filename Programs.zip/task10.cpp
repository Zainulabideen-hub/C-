#include<iostream>
using namespace std;

int main()
{
    int win,draw,loss,points;
    cout << "Enter wins" << endl;
    cin >> win;
    cout << "Enter draws" << endl;
    cin >> draw;
    cout << "Enter loss" << endl;
    cin >> loss;
    points=win*3+draw+loss*0;
    cout << "Points are:" <<points<< endl;
    return 0;
}