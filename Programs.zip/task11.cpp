#include<iostream>
using namespace std;

int main()
{
    long long int population,n,future;
    int month=30*12;
    cout << "Enter world population" << endl;
    cin >> population;
    cout << "Enter new born in a month" << endl;
    cin >> n;
    future=population+n*month;
    cout << "Population in 3 decade:"<<future << endl;
    
    
    return 0;
}