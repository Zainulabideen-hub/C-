#include<iostream>
using namespace std;

int main()
{
    float lb,kg;
    cout << "Enter weight in pound:" << endl;
    cin >> lb;
    kg=lb*0.45;
    cout << "Weight in kg:"<<kg << endl;
    return 0;
}