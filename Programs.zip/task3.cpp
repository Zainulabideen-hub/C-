#include<iostream>
using namespace std;

int main()
{
    float length,width,area;
    cout << "Enter length of triangle" << endl;
    cin >> length;
    cout << "Enter width of triangle" << endl;
    cin >> width;
    area=length*width;
    cout << "Area of triangle:" <<area<< endl;
    return 0;
}