#include<iostream>
using namespace std;

int main()
{
    float charge,time,current;
    cout << "Enter charge" << endl;
    cin >> charge;
    cout << "Enter time" << endl;
    cin >> time;
    current=charge/time;
    cout << "Current:"<<current << endl;
    return 0;
}