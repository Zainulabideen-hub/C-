#include<iostream>
using namespace std;

int main()
{
    string name;
    int matric,inter,ecat;
    float aggregate;
    cout << "Enter name" << endl;
    cin >> name;
    cout << "Enter matric marks" << endl;
    cin >> matric;
    cout << "Enter inter marks" << endl;
    cin >> inter;
    cout << "Enter ECAT marks" << endl;
    cin >> ecat;
    aggregate =(matric/1100*10)+(inter/550*40)+(ecat/400*50);
    cout << "Name:" <<name<< endl;
    cout << "Matric marks:" <<matric<< endl;
    cout << "Inter marks:" <<inter<< endl;
    cout << "Ecat marks:" <<ecat<< endl;
    cout << "Aggregate:"<<aggregate << endl;
    return 0;
}