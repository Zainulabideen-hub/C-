#include<iostream>
using namespace std;

int main()
{
    int mb,kb,byte,bit;
    cout << "Enter MB" << endl;
    cin >> mb;
    kb=1024*mb;
    byte=1024*kb;
    bit=8*byte;
    cout << "Bits:" <<bit<< endl;
    return 0;
}