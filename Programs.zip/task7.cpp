#include<iostream>
using namespace std;

int main()
{
    int hour,sec;
    cout << "Enter hours:" << endl;
    cin >> hour;
    sec=hour*360;
    cout << "Secons are:"<<sec << endl;
    return 0;
}