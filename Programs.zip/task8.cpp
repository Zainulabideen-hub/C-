#include<iostream>
using namespace std;

int main()
{
    float voltage, current,power;
    cout << "Enter voltage" << endl;
    cin >> voltage;
    cout << "Enter current" << endl;
    cin >> current;
    power=voltage*current;
    cout << "Power is:"<<power << endl;
    return 0;
}