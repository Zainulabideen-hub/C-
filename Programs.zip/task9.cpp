#include<iostream>
using namespace std;

int main()
{
    int year,days;
    cout << "Enter years" << endl;
    cin >> year;
    days=year*365;
    cout << "Days are:" <<days<< endl;
    return 0;
}